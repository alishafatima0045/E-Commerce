<?php 

$Con = mysqli_connect("localhost","root","","e project");

// if($Con){
//     echo "Connected";
// }
?>